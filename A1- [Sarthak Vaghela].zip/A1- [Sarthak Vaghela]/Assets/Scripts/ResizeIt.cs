﻿using UnityEngine;
using System.Collections.Generic;
using System.Collections;

public class ResizeIt : MonoBehaviour
{
   public int n=0;
   public int m=1; 

    void Start()
    {
        StartCoroutine(Resize());
    }

    IEnumerator Resize()
    {
        while(true)
        {
           while (true)
           {
                yield return new WaitForSeconds(1);

                if(m==2)
                {
                 transform.localScale -= new Vector3(1,1,1);
                 n++;
                 if(n%4==0)
                    m--;
                }

                else if(m==1)
                {
                 transform.localScale += new Vector3(1,1,1);
                 n++;
                 if(n%4==0)
                    m++;
                }

                if(m==2)
                {
                 transform.localScale -= new Vector3(1,1,1);
                 n++;
                 if(n%4==0)
                    m--;
                }

           }
        }
    }
}