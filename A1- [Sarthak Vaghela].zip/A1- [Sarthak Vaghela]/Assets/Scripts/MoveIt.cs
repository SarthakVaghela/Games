﻿using System.Collections.Generic;
using UnityEngine;
using System.Collections;

public class MoveIt : MonoBehaviour
{
    private bool rightdir = true;
    public float spd = 1.0f;            // here spd is speeed
    public float temp;
    public float nor;

    void Update()
    {
        if (rightdir)                                                          //applying conditions
            transform.Translate(Vector2.right * spd * Time.deltaTime);
        else
            transform.Translate(-Vector2.right * spd * Time.deltaTime);

        if (transform.position.x <= -3)                                        //moving left
        {
            rightdir = true;
        }

        if (transform.position.x >= 3.0f)                                      // moving right
        {
            rightdir = false;
        }
    }
}