﻿using UnityEngine;
using System.Collections.Generic;
using System.Collections;


public class RotateIt : MonoBehaviour
{
    public bool temp = true;
    public float vector;

    void Update() 
    {
        transform.Rotate (new Vector3 (30,60,90) * Time.deltaTime); 
    }
}
